(function($) {
	"use strict";
	
	lightGallery(document.getElementById('lightgallery'));
	
})(jQuery);
